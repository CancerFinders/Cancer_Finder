1.1.0 / 2016-06-21
==================

* add support for vertical SVG scale

1.0.1 / 2016-06-16
==================

* better support for very small and negative values

1.0.0 / 2016-06-16
==================

* first release
